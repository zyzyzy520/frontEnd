define({
  "name": "0826-axios练习-接口文档",
  "title": "接口文档",
  "url": "http://localhost:5000",
  "version": "1.0.0",
  "description": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-11-19T13:30:32.077Z",
    "url": "https://apidocjs.com",
    "version": "0.25.0"
  }
});
